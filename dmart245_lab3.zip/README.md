# Lab 1

## Student information
* Full name: Daniel Martinez Garzon
* E-mail: dmart245@ucr.edu
* UCR NetID: dmart245
* Student ID: 862179627

## Answers

* (Q1) Which of the following is the right way to call the IsEven function?

new IsEven().apply(5)

* (Q2) Did the program compile?

The program did not compile.

* (Q3) If it does not work, what is the error message you get?

`java: local variables referenced from a lambda expression must be final or effectively final`