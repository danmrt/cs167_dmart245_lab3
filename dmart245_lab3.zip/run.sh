mvn package
java -cp target/dmart245_lab3-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.dmart245.App 3 20 5
java -cp target/dmart245_lab3-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.dmart245.App 3 20 3,5
java -cp target/dmart245_lab3-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.dmart245.App 3 20 3v5